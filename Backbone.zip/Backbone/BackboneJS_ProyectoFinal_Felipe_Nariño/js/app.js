$(document).ready(function(){
	routerPrincipal = new RouterPrincipal();
	Backbone.history.start();
});